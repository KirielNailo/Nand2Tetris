#JackTokenizer.py
#
# CS2011   Project 10 & 11 Jack Compiler
#
# Summer 2013
# last updated 14 Oct 2021

from JTConstants import *
import re

############################################
# Class
class JackTokenizer(object):

############################################
# Constructor
    def __init__(self, filePath):
        loadedList = self.__loadFile(str(filePath))
        self.toParse = self.__filterFile(loadedList)

############################################
# instance methods
    def advance(self):
        '''reads and returns the next token, returns False if there are no more tokens.'''
        if self.toParse:
            return self.toParse.pop(0)
        else:
            return False

############################################
# private
    def __loadFile(self, fileName):
        '''Loads the file into memory.
           -fileName is a String representation of a file name, returns contents as a simple List'''            
        fileList = []
        file = open(fileName,"r")
        
        for line in file:
            fileList.append(line)
            
        file.close()

        return fileList

    def __filterFile(self, fileList):
        '''Comments, blank lines and unnecessary leading/trailing whitespace are removed from the list.
           -fileList is a List representation of a file, one line per element returns the fully filtered List'''
       
        filteredList = []
        
        for line in fileList:
            line = self.__filterOutEOLComments(line)                                #Filter out // comments
            line = self.__filterOutSingleLineBlockComments(line)                    #Filter out /* comments
            operands = re.split('(\W)', line)                                       #Split line on non-word characters  
            
            while '"' in operands:                                                  #Pull out stringConstants
                operands = self.__parseString(operands)
            
            for operand in operands: 
                operand = operand.strip()                                           #Get rid of white spaces
                if operand:
                    filteredList.append(operand)                                    #Append what's left to the token list

        return filteredList           

    def __filterOutEOLComments(self, line):
        '''Removes end-of-line comments and resulting whitespace.
           -line is a string representing single line, line endings already stripped returns the filtered line, which may be empty '''

        index = line.find('//')
        if (index >= 0):
            line = line[0:index]
            
        line = line.strip()
            
        return line 

    def __filterOutSingleLineBlockComments(self, line):
        '''Removes single line block comments and resulting whitespace.
           -line is a string representing single line, line endings already stripped returns the filtered line, which may be empty '''

        if '/*' in line:
            line = ''           
        
        if len(line) > 0:     
            if line[0] == '*':
                line = ''
        
        return line
        
    def __parseString(self, operands):
        ''' returns a stringConstant out of the line.
            -operands is a list composed out of all elements in a single line'''
        temp = []
        
        indexOne = operands.index('"')
        indexTwo = operands.index('"', indexOne+1)
        length = len(operands)
            
        for i in range(0, indexOne):
            temp.append(operands[i])
            
        SC = ''
        for i in range(indexOne+1, indexTwo):
            SC = SC + str(operands[i])
                
        temp.append('<stringConstant> ' + SC + ' </stringConstant>')
            
        for i in range (indexTwo+1, length):
            temp.append(operands[i])

        return temp 
#*****************************************************************
# Not used in current implementation
        
    def __parseInt(self, line):
        ''' returns an integerConstant out of the line.      
            -line is a string representing single line, line endings already stripped assumes there are no leading spaces '''
        pass
        ##TODO: complete  

    def __parseCharacters(self, line):
        ''' returns a token out of the line which could be an identifier or a keyword.
            -line is a string representing single line, line endings already stripped assumes there are no leading spaces '''
        pass
        ##TODO: complete         


#CompilationEngine.py
#
# CS2011   Project 10 & 11 Jack Compiler
#
# Summer 2013
# last updated 14 Oct 2021

from JTConstants import *
from SymbolTable import *

# Used for the peek/get/replace functions
TT_TOKEN = 0
TT_XML = 1

#map from Jack language purpose term in SymbolTable, to VM segment name
SEG = {'static':'static', 'field':'this', 'arg':'argument', 'var':'local'}
   
############################################
# Class
class CompilationEngine(object):

############################################
#static class variables
#   these will be shared across multiple instances

    labelID = 0

############################################
# Constructor
    def __init__(self, tokenList):
        self.tokens = tokenList
        self.indentation = 0

        #self.st = SymbolTable()             #for ch11
        #self.vmInstList = []                #for ch11
        #self.currentClassName = None        #for ch11
        
############################################
# static class methods
#    these methods are owned by the Class not one instance
#    note they do not have self as the first argument and they have the @staticmethod tag

    @staticmethod
    def __getLabelNumber():
        ''' a static utility method to access the class variable '''
        label = CompilationEngine.labelID
        CompilationEngine.labelID += 1
        return ( str(label) )

############################################
# instance methods
    def compileTokens(self):
        ''' primary call to do the final compilation.
            returns a list of properly identified structured XML with appropriate indentation.'''

        #the compilation recursive descent always starts with the <tokens> tag, and then calls __compileClass(),
        #  if it does not -- fail early because something is wrong, either in the tokenizing or how the file was output.
        #  **use the fail early technique throughout the compilation, you will always know which of a small number of
        #  possibilities you are looking for, if none of them are there raise the exception so you can start debugging
        
        result = []

        tokenTuple = self.__getNextEntry()

        if ( tokenTuple[TT_XML] == '<tokens>' ):
            result.extend( self.__compileClass() )

            tokenTuple = self.__getNextEntry()
            if ( tokenTuple[TT_XML] != '</tokens>' ):
                raise RuntimeError('Error, this file was not properly tokenized, missing </tokens>')
                
        else:
            raise RuntimeError('Error, this file was not properly tokenized, missing <tokens>')

        return result
        
    #for Ch11
    def get_vmInstructions(self):
        ''' returns a fully translated list of vm instructions, one instruction per list element '''
        return self.vmInstList

############################################
# private/utility methods
    def __getNextEntry(self):
        '''Removes the next token from the list of tokens returns a tuple (token, <tag> token </tag>), TT_TOKEN and TT_XML should be used for accessing tuple parts'''
        tokenString = self.tokens.pop(0)
        startIndex = tokenString.find('>') + 2              #handles included space assumption
        endIndex = tokenString.find('</') - 1
        tokenTuple = (tokenString[startIndex:endIndex], tokenString)
        return tokenTuple

    def __peekAtNextEntry(self):
        '''Copies, but does not remove the next token from the datastream returns a tuple (token, <tag> token </tag>), TT_TOKEN and TT_XML should be used for accessing tuple parts'''
        tokenString = self.tokens[0]
        startIndex = tokenString.find('>') + 2              #handles included space assumption
        endIndex = tokenString.find('</') - 1
        tokenTuple = (tokenString[startIndex:endIndex] , tokenString)
        return tokenTuple

    def __replaceEntry(self, entry):
        '''Returns a token to the head of the stream. Entry must properly be in the form <tag>token</tag>''' 
        self.tokens.insert(0, entry)

    def __compileClass(self):
        '''Compiles a class declaration, returning a list of VM commands. '''       
        result = []
        tokenTuple = self.__getNextEntry()
        if tokenTuple[TT_TOKEN] == 'class':
            
            #<class>
            result.append( '<class>' )                                                          #<class>
            self.indentation += 2  
            result.append( (self.indentation * ' ') + tokenTuple[TT_XML])                       #Keyword class
            result.extend(self.__append())                                                      #Classname identifier
            self.currentClassName = tokenTuple[TT_TOKEN]
            result.extend(self.__append())                                                      #Symbol '{'

            tokenTuple = self.__peekAtNextEntry()            
            while tokenTuple[TT_TOKEN] != '}':                                                  #While peek not '}'
                if (tokenTuple[TT_TOKEN] == 'field') or (tokenTuple[TT_TOKEN] == 'static'):     #if field | static
                    result.extend( self.__compileClassVarDec() )                                #__compileClassVarDec 
                elif( tokenTuple[TT_TOKEN] in SUBROUTINES ):                                    #if in SUBROUTINES
                    result.extend( self.__compileSubroutine())                                  #__compileSubroutine   
                else:
                    raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not subroutineDec or classVarDec')
                tokenTuple = self.__peekAtNextEntry()

            result.extend(self.__append())                                                      #Symbol '}'
            self.indentation -= 2
            result.append( '</class>' )                                                         #</class>           
        else:
            raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not class')
        
        return result

    def __compileClassVarDec(self):
        '''Compiles a class variable declaration statement, returning a list of VM commands. '''
        result = []        
        result.append( (self.indentation * ' ') + '<classVarDec>' )                             #<classVarDec>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword static or field
        result.extend(self.__append())                                                          #Keyword var type      
        result.extend(self.__append())                                                          #Identifier VarName

        tokenTuple = self.__peekAtNextEntry()            
        while tokenTuple[TT_TOKEN] != ';':                                                      #While peek not ';'
            result.extend(self.__append())                                                      #Symbol ','
            result.extend(self.__append())                                                      #Identifier varName
            tokenTuple = self.__peekAtNextEntry()

        result.extend(self.__append())                                                          #Symbol ';'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</classVarDec>' )                            #</classVarDec>
        
        return result
   
    def __compileSubroutine(self):
        '''Compiles a function/method, Returning a list of VM commands. '''        
        result = []    
        result.append( (self.indentation * ' ') + '<subroutineDec>' )                           #<subroutineDec>
        self.indentation += 2      
        result.extend(self.__append())                                                          #Keyword constructor/function/method    
        result.extend(self.__append())                                                          #Keyword void/type        
        result.extend(self.__append())                                                          #Subroutine name        
        result.extend(self.__append())                                                          #Symbol '(' 
        result.extend(self.__compileParameterList())                                            #__parameterList 
        result.extend(self.__append())                                                          #Symbol ')'
        result.extend(self.__compileSubroutineBody())                                           #__compileSubroutineBody      
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</subroutineDec>' )                          #</subroutineDec>
        
        return result
    
    def __compileParameterList(self):
        '''Compiles a parameter list from a function/method returning a list of VM commands. '''
        result = []       
        result.append( (self.indentation * ' ') + '<parameterList>')                            #parameterList
        self.indentation += 2       

        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] != ')'):                                                       #Closing ')' from subroutineDec; ( printed by subroutineDec
            result.extend(self.__append())                                                      #type    
            result.extend(self.__append())                                                      #varName

        tokenTuple = self.__peekAtNextEntry() 
        while tokenTuple[TT_TOKEN] == ',':                                                      #Preceding comma for the parameter in parameter list
            result.extend(self.__append())                                                      #Symbol ','
            result.extend(self.__append())                                                      #type    
            result.extend(self.__append())                                                      #varName           
            tokenTuple = self.__peekAtNextEntry()
        
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</parameterList>')                           #/parameterList, ')'
        
        return result
        
    def __compileSubroutineBody(self):
        '''Compiles a parameter list from a function/method returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<subroutineBody>')                           #<subroutineBody>
        self.indentation += 2                
        result.extend(self.__append())                                                          #Symbol '{'
        
        tokenTuple = self.__peekAtNextEntry()
        while tokenTuple[TT_TOKEN] != '}':                                                      #Check for closing '}'                  
            if (tokenTuple[TT_TOKEN] == 'var'):                                                 #if a varDec
                result.extend( self.__compileVarDec() )                                         #__compileVarDec
            elif tokenTuple[TT_TOKEN] in STATEMENTS:                                            #if a statement
                result.extend( self.__compileStatements())                                      #__compileStatements
            else: 
                raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not a variable declaration or a statement.')                
            tokenTuple = self.__peekAtNextEntry()
        
        result.extend(self.__append())                                                          #Symbol '}'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</subroutineBody>')                          #</subroutineBody>
        return result
  
    def __compileVarDec(self):
        '''Compiles a single variable declaration line, returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<varDec>')                                   #<varDec>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword var  
        result.extend(self.__append())                                                          #Identifier type 
        result.extend(self.__append())                                                          #Identifier varName
        
        tokenTuple = self.__peekAtNextEntry()                
        while tokenTuple[TT_TOKEN] != ';':                                                      #While peek not ';'
            result.extend(self.__append())                                                      #Symbol ','           
            result.extend(self.__append())                                                      #Identifier varName
            tokenTuple = self.__peekAtNextEntry()
              
        result.extend(self.__append())                                                          #Symbol ';' 
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</varDec>' )                                 #</varDec>
        
        return result

    def __compileStatements(self):
        '''Compiles statements, returning a list of VM commands, assumes any leading and trailing braces are consumed by the caller '''
        result = []       
        result.append( (self.indentation * ' ') + '<statements>')                               #<statements>
        self.indentation += 2

        tokenTuple = self.__peekAtNextEntry()       
        while  tokenTuple[TT_TOKEN] != '}':                                                     #While not '}'
            if (tokenTuple[TT_TOKEN] == 'let'):                                                 #if letStatement
                result.extend( self.__compileLet() )                                
            elif (tokenTuple[TT_TOKEN] == 'if'):                                                #if ifStatement
                result.extend( self.__compileIf())           
            elif (tokenTuple[TT_TOKEN] == 'while'):                                             #if whileStatement
                result.extend( self.__compileWhile())
            elif (tokenTuple[TT_TOKEN] == 'do'):                                                #if doStatement
                result.extend( self.__compileDo())          
            elif (tokenTuple[TT_TOKEN] == 'return'):                                            #if returnStatement
                result.extend( self.__compileReturn())            
            else:
                raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not a valid Statement')                          
            tokenTuple = self.__peekAtNextEntry()
              
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</statements>' )                             #</statements>
        return result

    def __compileLet(self):
        '''Compiles a variable assignment statement, returning a list of VM commands. '''
        result = []      
        result.append( (self.indentation * ' ') + '<letStatement>')                             #<letStatement>
        self.indentation += 2       
        result.extend(self.__append())                                                          #Keyword let        
        result.extend(self.__append())                                                          #Identifier varName

        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] == '['):                                                       #Check for array indicator [      
            result.extend(self.__append())                                                      #Symbol '['
            result.extend( self.__compileExpression())                                          #__compileExpression
            result.extend(self.__append())                                                      #Symbol ']'
               
        result.extend(self.__append())                                                          #Symbol '='        
        result.extend( self.__compileExpression())                                              #__compileExpression 
        result.extend(self.__append())                                                          #Symbol ';'        
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</letStatement>' )                           #</letStatement>
        
        return result
        
    def __compileIf(self):
        ''' compiles an if(else)? statement ''' 
        result = []  
        result.append( (self.indentation * ' ') + '<ifStatement>')                              #<ifStatement>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword if       
        result.extend(self.__append())                                                          #Symbol '('
        result.extend( self.__compileExpression())                                              #__compileExpression       
        result.extend(self.__append())                                                          #Symbol ')'  
        result.extend(self.__append())                                                          #Symbol '{'
        result.extend( self.__compileStatements())                                              #__compileStatements
        result.extend(self.__append())                                                          #Symbol '}'

        tokenTuple = self.__peekAtNextEntry()                 
        if (tokenTuple[TT_TOKEN] == 'else'):                                                    #verify if 'if' has 'else'            
            result.extend(self.__append())                                                      #Keyword else            
            result.extend(self.__append())                                                      #Symbol '{'           
            result.extend( self.__compileStatements())                                          #__compileStatements           
            result.extend(self.__append())                                                      #Symbol '}'
               
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</ifStatement>' )                            #</ifStatement>
        
        return result
        
    def __compileWhile(self):
        '''Compiles a while loop, returning a list of VM commands. '''
        result = []       
        result.append( (self.indentation * ' ') + '<whileStatement>')                           #<whileStatement>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword while
        result.extend(self.__append())                                                          #Symbol '('
        result.extend( self.__compileExpression())                                              #__compileExpression
        result.extend(self.__append())                                                          #Symbol ')'
        result.extend(self.__append())                                                          #Symbol '{'
        result.extend( self.__compileStatements())                                              #__compileStatements
        result.extend(self.__append())                                                          #Symbol '}'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</whileStatement>' )                         #</whileStatement>
        return result

    def __compileDo(self):
        '''Compiles a function/method call, returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<doStatement>')                              #<doStatement>
        self.indentation += 2 
        result.extend(self.__append())                                                          #Keyword do
        result.extend( self.__compileSubroutineCall())                                          #__compileSubroutineCall
        result.extend(self.__append())                                                          #Symbol ';'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</doStatement>' )                            #</doStatement>
        
        return result

    def __compileReturn(self):
        '''Compiles a function return statement, returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<returnStatement>')                          #<returnStatement>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword return
        
        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] != ';'):                                                       #if not ';'
            result.extend( self.__compileExpression())                                          #__compileExpression

        result.extend(self.__append())                                                          #Symbol ';'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</returnStatement>' )                        #</returnStatement>
        
        return result

    def __compileExpression(self):
        '''Compiles an expression, returning a list of VM commands.'''
        result = []      
        result.append( (self.indentation * ' ') + '<expression>')                               #<expression>
        self.indentation += 2
        
        result.extend( self.__compileTerm())                                                    #__compileTerm
                                                                       
        tokenTuple = self.__peekAtNextEntry()       
        while tokenTuple[TT_TOKEN] in BINARY_OPERATORS:                                         #Check if next token is an operator          
            result.extend(self.__append())                                                      #Operator
            result.extend( self.__compileTerm())                                                #__compileTerm
            tokenTuple = self.__peekAtNextEntry()
            
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</expression>' )                             #</expression>
        return result

    def __compileTerm(self):
        '''Compiles a term, returning a list of VM commands.'''
        result = []
        result.append( (self.indentation * ' ') + '<term>')                                     #<term>
        self.indentation += 2
        
        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] == '('):                                                       #expression case, look for '(' indicator          
            result.extend(self.__append())                                                      #Symbol '('
            result.extend( self.__compileExpression())                                          #__compileExpression           
            result.extend(self.__append())                                                      #Symbol ')'
        elif tokenTuple[TT_TOKEN] in SYMBOLS:                                                   #"unaryOP term" case
            result.extend(self.__append())                                                      #operator
            result.extend(self.__compileTerm())                                                 #__compileTerm
        else:                                                                                   #...in every other case
            result.extend(self.__append())                                                      #integerConstant | stringConstant | keywordConstant | varName | first element of subroutineCall            
            tokenTuple = self.__peekAtNextEntry()           
            if (tokenTuple[TT_TOKEN] == '['):                                                   #Resolve array in varName[expression]   
                result.extend(self.__append())                                                  #Symbol '['
                result.extend(self.__compileExpression())                                       #__compileExpression
                result.extend(self.__append())                                                  #Symbol ']'
            elif tokenTuple[TT_TOKEN] == '(' or tokenTuple[TT_TOKEN] == '.' :                   #resolve subroutineCall case; since we already added first element... need to account for it in the function call
                result.extend(self.__compileSubroutineCall())                                   #__compileSubroutineCall
        
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</term>' )                                   #</term>
        
        return result

    def __compileExpressionList(self):
        ''' compiles a list of expressions such as found in a list of arguments for a function call (one expression per argument) 
            returning a tuple whose 0th item is a list of VM commands and the 1th item is the number of parameters in the subroutine. ''' 
        result = []
        num_params = 0
        result.append( (self.indentation * ' ') + '<expressionList>')                           #<expressionList>
        self.indentation += 2
 
        tokenTuple = self.__peekAtNextEntry()
        if tokenTuple[TT_TOKEN] != ')':                                                         #Check for symbol ')' -> closing for subroutineCall
            result.extend( self.__compileExpression())                                          #__compileExpression
            num_params += 1
            
            tokenTuple = self.__peekAtNextEntry()                                       
            while tokenTuple[TT_TOKEN] == ',':                                                  #check for continued expressions           
                result.extend(self.__append())                                                  #Symbol ','
                result.extend( self.__compileExpression())                                      #__compileExpression
                num_params += 1
                tokenTuple = self.__peekAtNextEntry()

        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</expressionList>' )                         #</expressionList>
        
        return (result, num_params)

    def __compileSubroutineCall(self):
        '''Compiles a subroutine call, returning a list of VM commands.'''
        result = []
        tokenTuple = self.__peekAtNextEntry()
        if tokenTuple[TT_TOKEN] != '(' and tokenTuple[TT_TOKEN] != '.' :                        #NOT calling it from the term, first element is not applied 
            result.extend(self.__append())                                                      #Subroutine name | className | varName
        
        tokenTuple = self.__peekAtNextEntry()                                                   #expression case '('        
        if (tokenTuple[TT_TOKEN] == '('):      
            result.extend(self.__append())                                                      #Symbol '('
            result.extend( self.__compileExpressionList()[0])                                   #__compileExpressionList
            result.extend(self.__append())                                                      #Symbol ')'
        elif tokenTuple[TT_TOKEN] == '.':                                                       #className | varName case
            result.extend(self.__append())                                                      #Symbol '.'        
            result.extend(self.__append())                                                      #Subroutine name 2
        
            tokenTuple = self.__peekAtNextEntry()                          
            if (tokenTuple[TT_TOKEN] == '('):                                                   #expression case '('    
                result.extend(self.__append())                                                  #Symbol '('
                result.extend( self.__compileExpressionList()[0])                               #__compileExpressionList
                result.extend(self.__append())                                                  #Symbol ')'
        
        return result
        
    def __append(self):
        '''Gets next token, appends next token to the results. Keeps me honest with the order of operations.'''
        result = []       
        tokenTuple = self.__getNextEntry()
        result.append( (self.indentation * ' ') + tokenTuple[TT_XML])
        #print((self.indentation * ' ') + tokenTuple[TT_XML])
        
        return result

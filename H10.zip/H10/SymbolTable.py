#SymbolTable.py
#
# CS2011   Project 10/11 Jack Compiler
#
# Fall 2019
# last updated 14 Oct 2021

from JTConstants import *

#public constant
SYM_DEFINE = 0
SYM_USE = 2

#constant only needed inside this file
TYPE = 0
KIND = 1
INDEX = 2

class SymbolTable(object):
############################################
# Constructor
    def __init__(self):
        self.classScope = dict()
        self.subroutineScope = dict()

        #TODO - finish implementing for 11

############################################
# instance methods
    def startSubroutine(self):
        ''' starts a subroutine scope. '''
        #TODO - implement for 11 and remove the pass
        pass
 
    def define(self, name, identifierType, kind):
        ''' defines a new identifier into the table.
            gets index for appropriate segment and places entry into correct scope
             static and field into class
             arg and var into subroutine
     
            arguments:
             -name:             the identifier itself
             -identifierType:   string identifying the type
             -kind:             'static' | 'field' | 'arg' | 'var' '''

        #TODO - implement for 11 and remove the pass
        pass

    def typeOf(self, name):
        ''' returns the type of the identifier'''
        #TODO - implement for 11 and remove the pass
        pass

    def kindOf(self, name):
        ''' returns the kind of the identifiers:
            'static' | 'field' | 'arg' | 'var' '''
        #TODO - implement and remove the pass
        pass

    def indexOf(self, name):
        ''' returns the segment index of the identifier'''
        #TODO - implement for 11 and remove the pass
        pass

   # def getIdentifierXML(self, name, how):
        ''' returns a properly formateted XML line for the variable -name
                -how:  SYM_DEFINE | SYM_USE '''
        
         #TODO - finish implementing for 11
   #      pass           

    def howMany(self, kind):
        ''' returns how many variables have been declared for segment kind
                -kind:  'static' | 'field' | 'arg' | 'var' '''
        #TODO - implement for 11 and remove the pass
        pass

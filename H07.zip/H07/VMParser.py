#VMParser.py
#Loren Peitso (template)
#ver. Ha
#CS2011   Project 7/8 Stack Operations
#Fall 2019
#last updated 20Jul22

class VMParser(object):

############################################
# Constructor
    def __init__(self, filePath):
        self.toParse = self.__filterFile( self.__loadFile(str(filePath)) )  #Run filter function                       

############################################
# instance methods
    def advance(self):
        '''Reads and returns the next command in the input, returns false if there are no more commands.  '''
        if self.toParse:
            return self.toParse.pop(0)
        else:
            return False

############################################
# related functions
    def command(line):
        '''Returns the line's command '''                
        if line: 
            return line.split()[0]
  
    def arg1(line):
        '''Returns the line's first argument '''
        if line: 
            return line.split()[1]

    def arg2(line):
        '''Returns the line's second argument '''
        if line: 
            return line.split()[2]
        
############################################
# private/utility methods
    def __loadFile(self, fileName):
        '''Loads the file into memory.
           -fileName is a String representation of a file name, returns contents as a simple List'''    
        fileList = []
        file = open(fileName,"r")
        
        for line in file:
            fileList.append(line)
            
        file.close()
        
        return fileList

    def __filterFile(self, fileList):
        '''Comments, blank lines and unnecessary leading/trailing whitespace are removed from the list.
           -fileList is a List representation of a file, one line per element returns the fully filtered List'''
        
        filteredList = []
        
        for line in fileList:
            line = self.__filterOutEOLComments(line)
            line = line.strip()               #leading and trailing whitespace removal
            
            if line:                          #empty line removal
                filteredList.append(line)
        
        return filteredList

    def __filterOutEOLComments(self, line):
        '''Removes end-of-line comments.
           -line is a string representing single line returns the filtered line, which may be empty'''

        index = line.find('//')
        if index >= 0:
            line = line[0:index]

        return line
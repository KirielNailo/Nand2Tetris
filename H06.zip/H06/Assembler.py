# Assembler.py
# CS2001   Project 6 Assembler
# 31 July 2013
# last updated 19JUL22
# inprog code; ver. Ha

import sys  #for command line launch functionality
from Code import *
from SymbolTable import *
from Parser import *

'''Manages the assembly process, used the Parser to do the mechanical tokenizing and then
   determines the semantically correct thing to do with those tokens. Then uses the Parser
   to break tokens into appropriate components and requests the translations of those
   components from the Code module. Labels are passed to the SymbolTable to get mapped
   against addresses.'''
class Assembler(object):

##########################################
#Constructor
    def __init__(self, target):

        index = target.find('.asm')
        if ( index < 1):
            raise RuntimeError( "error, cannot use the filename: " + target )

        self.inputFileName = target                                     #Set input file
        self.outputFileName = self.inputFileName[:index] + '.hack'      #Set output file
        self.parser = Parser(self.inputFileName)                        #Initialize Parser, pass it the input file
        self.code = Code()                                              #Initialize Code
        self.st = SymbolTable()                                         #Initialize Symbol Table

##########################################
#public methods

    def assemble(self):
        '''Does the assembly and creates the file of machine commands, returning the name of that file '''
        self.__firstPass()                                              #Run firstPass function
        return  self.__output( self.__secondPass() )                    #Run and output secondPass function

##########################################
#private/local methods
 
    def __output(self, codeList):
        '''Outputs the machine code codeList into a file and returns the filename'''
        file = open(self.outputFileName,"w")
        file.write("\n".join(codeList))
        file.close()
        return self.outputFileName

    def __firstPass(self):
        ''' Passes over the file contents to populate the symbol table with label declarations'''
        labels = self.parser.processLabels()                            #Get all labels out of code using parser slice and dice
        
        for i in labels:                                                #Loop through the label list
            if self.st.contains(i):                                     #Make sure there aren't any repeating labels
                raise RuntimeError( 'Labels must be unique. Offending label is ' + i)
            else:
                self.st.addEntry(i, labels.get(i))                      #Add label to the symbol table along with its command address
            
    def __secondPass(self):
        ''' Manage the translation to machine code, returning a list of machine instructions'''
        machineCode = []                                                #Initialize empty array

        command = self.parser.advance()                                 #Get next command

        while( command ):                                               #If the command is valid (will kick False if ain't no more command, Chief
            if self.parser.commandType(command) == Parser.A_COMMAND:    #Is it an A-command?..
                bitString=self.__assembleA(command)                     #...treat it as such
            elif self.parser.commandType(command) == Parser.C_COMMAND:  #Is it a C-command?..
                bitString=self.__assembleC(command)                     #...treat it as such
            else:                                                       #Oterwise you gave poor computer some malformed garbage
                print('ERROR!   ', self.parser.symbol(command))
                raise RuntimeError( 'There should be no labels on second pass, errant symbol is ' + self.parser.symbol(command))

            machineCode.append(bitString)                               #Add newly formed string to our machineCode array... 
            command = self.parser.advance()                             #And get the next command

        return machineCode

    def __assembleC(self, command):
        ''' Do the mechanical work to translate a C_COMMAND, returns a string representation of a 16-bit binary word.'''
        dest = ''                                                       #Declare variables
        jump = ''
        comp = ''
        
        if self.parser.dest(command):                                   #If dest part isn't null...
            dest = self.code.dest(self.parser.dest(command))            #...pull it out, convert to bin
        else:
            dest = '000'                                                #Or use a blank code otherwise
            
        if self.parser.jump(command):                                   #If jump part isn't null...
            jump = self.code.jump(self.parser.jump(command))            #...pull it out, convert to bin
        else:
            jump = '000'                                                #Or use a blank code otherwise
            
        if self.parser.comp(command):                                   #If jump part isn't null...
            comp = self.code.comp(self.parser.comp(command))            #...pull it out, convert to bin
        else:
            raise RuntimeError( 'C-command should always have COMP field, errant command is' + command)
        
        command = '111' + comp + dest + jump                            #Concatenate the pieces
        
        return command

    def __assembleA(self, command):
        ''' Do the mechanical work to translate an A_COMMAND, returns a string representation of a 16-bit binary word.'''
        command=self.parser.symbol(command)                             #Strip leading @ identifier off A-command
        if not command.isnumeric():                                     #Check if the command is a a variable
            if self.st.contains(command):                               #Check if symbol table has it already, if so,..
                command = self.st.getAddress(command);                  #...return its address
            else:                                                       #Otherwise, we'll add it to the symbol table, then get its address
                self.st.addEntry(command, self.st.getNextVariableAddress())
                command = self.st.getAddress(command);
        
        command = '0'+format(int(command), '015b')                      #Convert number to int -> binary, add leading zeroes to assure length 15, add 0 to the front to ID A-command
                                                        
        return command
        
#################################
#this kicks off the program and assigns the argument to a variable

'''Keeping long file paths for internal testing purposes.'''
if __name__=="__main__":
    target = sys.argv[1]                                                #Feed command line argument as a file name      
   
assembler = Assembler(target)
print('done parsing, assembled file is:', assembler.assemble() )

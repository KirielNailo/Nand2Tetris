# Parser.py
# CS2001   Project 6 Assembler
# 31 July 2013
# last updated 19JUL22
# Complete code; ver. Ha
# Self-reminder: due to my local implementation, path screwage is a thing, command line works

'''Manages the mechanical work of breaking the input into tokens, and later further breaking
   down presented tokens into component chunks.  The Parser does not know what the chunks mean
   or what to do with them, it just knows how to slice-and-dice. '''

class Parser(object):
    A_COMMAND = 1
    C_COMMAND = 2
    L_COMMAND = 3

##########################################
#Constructor
    def __init__(self, fileName):                               #Initialization
        loadedList = self.__loadFile(fileName)                  #Load the file provided in the command line
        self.toParse = self.__filterFile(loadedList)            #Run filter function

##########################################
#public Methods
    def advance(self):
        '''reads and returns the next command in the input, returns false if there are no more commands.  '''
        if len(self.toParse):                                   #Check if there is anything left to parse, return False otherwise
            line=self.toParse[0]                                #Grab next instruction
            self.toParse.remove(line)                           #Kill the line we just grabbed
            return line
        else:
            return False
        
    def commandType(self, command):
        ''' returns type of the command
            Parser.A_COMMAND   @xxx
         or Parser.C_COMMAND   c-commands
         or Parser.L_COMMAND   a label e.g. (LABEL)
        '''
        result = 0                                              #initialized to a tattle-tail value
        
        if command[0] == '@':                                   #Identify A-command
            result=Parser.A_COMMAND
        elif command[0] == '(':                                 #Identify L-command
            result=Parser.L_COMMAND
        else:                                                   #If not A- or L-command, must be C-command
            result=Parser.C_COMMAND
        
        return result

    def symbol(self, command):
        ''' returns symbol or decimal of an A-command or symbol of a label'''        
        result=0
        
        if command[0] == '@':                                   #Identify A-command
            result=command[1:]                                  #Strip first character @ of the A-command
        elif command[0] == '(':                                 #Identify L-command
            result=command[1:-1]                                #Strip first and last character () of the command
        else:                                                   #Eliminate silent failures wherever possible
            raise RuntimeError("Error!!! parse.symbol(): We should never parse a symbol from a C_COMMAND")
            result = None
            
        return result

    def dest(self, command):
        ''' returns the dest mnemonic portion of the command '''
        dest = False                                            #Set dest to False
        if '=' in command:                                      #Check if '=' is in command; if so, split the command on =, return left side
            dest, equals, comp = command.partition('=')

        return dest
    
    def jump(self, command):
        ''' returns the jmp mnemonic portion of the command '''
        jump = False                                            #set jump to False
        if ';' in command:                                      #Check if ';' is in command; if so, split the command on ;, return right side
            comp, equals, jump = command.partition(';')

        return jump
    
    def comp(self, command):
        ''' returns the comp mnemonic portion of the command '''
        comp=False                                              #Set comp to False; ready to call an error if this ever procs
        if '=' in command:                                      #Cut off left side of command if = is present
            dest, equals, comp = command.partition('=')
        if ';' in command:                                      #Cut off right side of command if ; is present 
            comp, equals, jump = command.partition(';')
 
        return comp                                             #Give back what's left

    def processLabels(self):
        ''' Passes over the list of commands and removes labels from the code being parsed.
            As labels are identified they are added to a dictionary of <label, romAddress>
            pairs.  After passing over the entire file the dictionary is returned. '''        
        labels = dict()

        i = 0                                                   #Introducing a very non-pythonic loop
        n = len(self.toParse)                                   
        while i < n:                                            #Catches double labels, though. AKA WORKS. Example of very pythonic (and non-working) loop below
            element = self.toParse[i]                           
            if self.commandType(element) == Parser.L_COMMAND:   #If we find L-command
                labels[self.symbol(element)] = self.toParse.index(element)  
                                                                #...add it to the dictionary, alongside its current index...
                self.toParse.remove(element)                    #...and kill that line altogheter. Semantics of assigning it to a Symbol Table will be handled elsewhere, we just chop-chop.
                n = n - 1                                       #Index magic to compensate for the removed body parts
            else:
                i = i + 1
        
        '''This is broken. Keeping here as a reminder to myself that "pythonic" isn't necessarily good, or WORKING.''' 
        #for i in self.toParse:                                  #Run through the to Parse list
        #    if self.commandType(i) == Parser.L_COMMAND:         #If we find L-command...
        #        labels[self.symbol(i)] = self.toParse.index(i)  #...add it to the dictionary, alongside its current index...
        #        self.toParse.remove(i)                          #...and kill that line altogheter. Semantics of assigning it to a Symbol Table will be handled elsewhere, we just chop-chop.       
        
        return labels 

##########################################
#private/local Methods
    def __loadFile(self, fileName):
        '''Loads the file into memory.
           -fileName is a String representation of a file name, returns contents as a simple List.'''       
        fileList = []                                           #Initialize fileList array

        with open(fileName) as f:                               #Open file name, initiate as f
            fileList = [line.strip() for line in f]             #Add each line in f to fileList, strip \n in the same pass 
        
        f.close()                                               #Close the file, because we clean up after ourselves
        
        return fileList

    def __filterFile(self, fileList):
        '''Comments, blank lines and unnecessary leading/trailing whitespace are removed from the list.
           -fileList is a List representation of a file, one line per element returns the fully filtered List'''
        
        filteredList = []                                       #Initialze filteredList array
      
        for i in fileList:                                      #Loop through the fileList with a counter
            line = i                                            #Initialize line to the next line in the fileList
            line = self.__filterOutEOLComments(line)            #Strip End of Line comment
            line = line.strip()                                 #Strip leading and trailing spaces
        
            if line != '':                                      #If the line is not null, append to the filteredList
                filteredList.append(line)
        
        return filteredList                                    

    def __filterOutEOLComments(self, line):
        '''Removes end-of-line comments.
           -line is a string representing single line returns the filtered line, which may be empty'''       
        line, separator, comment = line.partition('//')         #Separate the line into code piece and comment piece on //

        return line

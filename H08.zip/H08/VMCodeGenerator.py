#VMCodeGenerator.py
#Loren Peitso (template)
#ver. Ha
#CS2011   Project 7/8 Stack Operations
#Fall 2019
#last updated 08Aug22

from pathlib import *
from VMParser import *

class VMCodeGenerator(object):
    
############################################
# Constructor    
    def __init__(self, filePath):
        self.fileName = filePath.stem                                       #FileName for variable creation
        self.currentFunction = self.fileName+'.'                            #Let's set initial function to FileName, in case there aren't any functions in the file           
        self.labelID = 0                                                    #Initiate label counter to 0

        self.tokenToCommandDict = {                                         #Command dictionary: launches appropriate function based on passed command
            'add' : self.__arithmetic,
            'sub' : self.__arithmetic,
            'neg' : self.__arithmetic,
            'and' : self.__arithmetic,
            'or'  : self.__arithmetic,
            'not' : self.__arithmetic,
            
            'eq' : self.__conditional,
            'gt' : self.__conditional,
            'lt' : self.__conditional,
    
            'push' : self.__push,
            'pop'  : self.__pop
        }

        self.tokenToCommandDict['label'] = self.__generateLabel
        self.tokenToCommandDict['if-goto'] = self.__generateIf
        self.tokenToCommandDict['goto'] = self.__generateGoto
        self.tokenToCommandDict['function'] = self.__generateFunction
        self.tokenToCommandDict['return'] = self.__generateReturn
        self.tokenToCommandDict['call'] =  self.__generateCall
        
        self.addressDict = {                                                #Fixed register dictionary. Mostly for my convenience. 
            'local':    'LCL',                                              #Base R1
            'argument': 'ARG',                                              #Base R2
            'this':     'THIS',                                             #Base R3
            'that':     'THAT',                                             #Base R4
            'pointer':  3,                                                  #R3-R4
            'temp':     5,                                                  #R5-12
                                                                            #R13-15 are MINE
            'static':   16,                                                 #Edit R16-255
        }

############################################
# instance methods
    def translateLine(self, line):
        '''Takes a line from parser, and runs an appropriate decode function'''
        command = VMParser.command(line)   
        return self.tokenToCommandDict[command](line)
         
    def generateInit(self): 
        ''' Generation Hack assembler code for program initialization:
                SP = 256.
                pointers = -1 (true)    #we add this beyond book requirement as a boot security technique
                Call Sys.Init()
        '''       
        lines = []
        lines.append('//generateInit')             
        lines.append('@256')                                                #Set SP to 256
        lines.append('D=A')
        lines.append('@SP')
        lines.append('M=D')
        
        for i in range(4):                                                  #Zeroize the pointers
            lines.append('A=A+1')
            lines.append('M=-1')
        
        for i in self.translateLine('call Sys.init 0'):                     #Call Sys.init 0
            lines.append(i)                                      
        
        return lines
    
    def end(self):
        '''Creates infinite loop to be executed at program completion'''
        lines = []
        
        lines.append('(END)')                                               #Self-explanatory
        lines.append('@END')                                                #Some provided programs have it embedded. I do not expect them to. 
        lines.append('0;JMP')
        
        return lines
        
############################################
# private/utility methods
    def __arithmetic(self, command):
        ''' Handle generation of Hack assembler code for the basic arithmetic commands '''
        lines = []
        lines.append('//__arithmetic')                                      #Comment for what it is
        
        if command not in ['neg', 'not']:                                   #Check for binary operation
            for i in self.__off():                                          #Pop off the stack
                lines.append(i)

        if command == 'add':                                                #Arithmetic operands
            lines.append('M=D+M')
        elif command == 'sub':
            lines.append('M=M-D')
        elif command == 'and':
            lines.append('M=D&M')
        elif command == 'or':
            lines.append('M=D|M')
        elif command == 'neg':                                              #Minor special cases for neg and not
            lines.append('@SP')
            lines.append('A=M-1')
            lines.append('M=-M')
        elif command == 'not':
            lines.append('@SP')
            lines.append('A=M-1')
            lines.append('M=!M')
        
        return lines 

    def __conditional(self, command):
        ''' Generates and returns Hack assembler code for the basic conditional commands,
            -command is the boolean comparison operator, Hack VM lang provides it in lowercase'''
        lines = []
        lines.append('//__conditional')                                     #Comment for what it is
        
        for i in self.__off():                                              #Pop off the stack
            lines.append(i)
        
        lines.append('D=M-D')                                               #Math
        lines.append('@'+self.fileName+'.IF_TRUE_L'+str(self.labelID))

        #Logic for the manner of jump
        if command == 'eq':                                                 #x == y, --> x - y == 0
            lines.append('D;JEQ') 
        elif command == 'gt':
            lines.append('D;JGT')                                           #x > y, --> x - y > 0
        elif command == 'lt':
            lines.append('D;JLT')                                           #x < y, --> x - y < 0

        lines.append('D=0')
        lines.append('@'+self.fileName+'.IF_FALSE_L'+str(self.labelID))
        lines.append('D;JMP')
        lines.append('('+self.fileName+'.IF_TRUE_L'+str(self.labelID)+')')
        lines.append('D=-1')
        lines.append('('+self.fileName+'.IF_FALSE_L'+str(self.labelID)+')')
        lines.append('@SP')
        lines.append('A=M-1')
        lines.append('M=D')
 
        self.labelID += 1                                                   #Increment label
               
        return lines

    def __push(self, line):
        ''' Generates and returns Hack assembler code for command 'push' '''
        lines = []
        arg1 = VMParser.arg1(line)                                          #Get the segment type
        arg2 = VMParser.arg2(line)                                          #... and serial number

        lines.append('//__push')                                            #Comment for what it is
        
        if arg1 == 'constant':                                              #Handle constants; simply append Arg2 as is
            lines.append('@' + str(arg2))           
        elif arg1 == 'static':                                              #Handle statics; FileName.Arg2
            lines.append('@' + self.fileName + '.' + str(arg2))
        elif arg1 == 'pointer':                                             #Handle pointers; 3+offset
            lines.append('@' + str(3 + int(arg2)))
        elif arg1 == 'temp':                                                #Handle temp; 5+offset
            lines.append('@' + str(5 + int(arg2)))   
        elif arg1 in ['local', 'argument', 'this', 'that']:
            lines.append('@'+str(self.addressDict.get(arg1)))           
            lines.append('D=M')                                             #Handle all other cases
            lines.append('@' + str(arg2))
            lines.append('A=D+A')
        else:                                                               #Error check
            raise RuntimeError ('Unknown argument', arg1)
        
        if arg1 == 'constant':                                              #Set D based on whether its a constant assignment or not
            lines.append('D=A')
        else:
            lines.append('D=M')
        
        for i in self.__pushDtoStack():                                     #D to stack
            lines.append(i)
        
        return lines
        
    def __pop(self, line):
        ''' Generates and returns Hack assembler code for command 'pop' '''    
        lines = []
        arg1 = VMParser.arg1(line)                                          #Get the segment type...
        arg2 = VMParser.arg2(line)                                          #...and serial number
        
        lines.append('//__pop')                                             #Comment for what it is
        
        if arg1 in ['pointer', 'temp', 'static']:                           #Handle special cases
            for i in self.__popStacktoD():                                  #Stack to D
                lines.append(i)
            if arg1 == 'pointer':                                           #Handle pointers...
                lines.append('@'+ str(3+int(arg2)))
            elif arg1 == 'temp':                                            #...temp... 
                lines.append('@'+ str(5+int(arg2)))
            else:                                                           #...and statics
                lines.append('@'+self.fileName+'.'+str(arg2))
        else:                                                               #Manage all other cases
            lines.append('@'+str(self.addressDict.get(arg1)))
            lines.append('D=M')
            lines.append('@'+str(arg2))       
            lines.append('D=D+A')
            lines.append('@R15')                                            #Store resolved address in R15
            lines.append('M=D')
            
            for i in self.__popStacktoD():                                  #Stack to D
                lines.append(i)

            lines.append('@R15')                                            #Recall resolved address from R15
            lines.append('A=M')
        
        lines.append('M=D')
        
        return lines
 
    def __off(self):
        '''Service function for decrementing stack marker'''
        lines = []
        
        lines.append('@SP')
        lines.append('AM=M-1')
        lines.append('D=M')
        lines.append('A=A-1')
        
        return lines       
        
    def __pushDtoStack(self):
        '''Push from D to stack, increment @SP'''
        lines = []
                       
        lines.append('@SP')                                                 #Get current SP
        lines.append('A=M')                                                 #Set address to current SP
        lines.append('M=D')                                                 #Write data to top of stack
        lines.append('@SP')                                                 #Increment SP
        lines.append('M=M+1')
        
        return lines

    def __popStacktoD(self):
        '''Decrement @SP, pop from stack to D'''
        lines = []
        
        lines.append('@SP')
        lines.append('AM=M-1')                                              #Decrement SP and current address
        lines.append('D=M')                                                 #Get data from top of stack
        
        return lines

    def __resolveSymbol(self, label):
        ''' Creates globally unique symbols'''
        
        label = str(self.currentFunction) + label                           #Set up new symbol in the format "CurrenFunction" + Label
                                                                            #Convention, no repeat labels in the ".vm" file
        return label

    def __generateLabel(self, line):
        ''' Generates and returns Hack assembler label code for function navigation when we find a VM label command.  '''
        lines = []
        lines.append('//__generateLabel')
        
        lines.append('('+self.__resolveSymbol(line.split()[1])+')')         #Code to generate a label... resilveSymbol in parenthesis
        
        return lines

    def __generateGoto(self, line):
        ''' Generates and returns Hack assembler goto code for structured function navigation '''
        lines = []
        lines.append('//__generateGoto')
       
        lines.append('@'+self.__resolveSymbol(line.split()[1]))             #Set a marker
        lines.append('0;JMP')                                               #Jump
        
        return lines

    def __generateIf(self, line):
        ''' Generates and returns Hack assembler conditional code for structured function navigation '''
        lines = []
        lines.append('//__generateIf')
        
        for i in self.__popStacktoD():                                      #Stack to D
            lines.append(i)
        lines.append('@'+self.__resolveSymbol(line.split()[1]))             #Set marker
        lines.append('D;JNE')                                               #Jump
        
        return lines
        
    def __generateFunction(self, line):
        ''' Generates and returns Hack assembler function loading code for structured function navigation.'''
        lines = []
        fnName = line.split()[1]
        numLocals = line.split()[2]
        lines.append('//__generateFunction' + ', ' + fnName + ', ' + numLocals)
        
        lines.append(str('({})').format(fnName))                            #Create function name label
        lines.append('D=0')                                                 #Set D to zero
            
        for i in range(0, int(numLocals)):                                  #Push numLocals zeroes to stack
            for i in self.__pushDtoStack():                                 
                lines.append(i)
        
        return lines
        
    def __generateCall(self, line):
        ''' Generates and returns Hack assembler function calling code for structured function navigation '''
        lines = []
        fnName = line.split()[1]
        numArgs = line.split()[2]
        lines.append('//__generateCall' + ', '  + fnName + ', ' + numArgs)  #Describe the fucntion in assembler
   
        lines.append('@'+str(self.currentFunction)+'L'+str(self.labelID))   #Function marker
        
        lines.append('D=A')
        for i in self.__pushDtoStack():                                     #Push current A to stack   
                lines.append(i)
                
        pointers = ('@LCL', '@ARG', '@THIS', '@THAT')                       #Save pointers on the stack
        
        for i in pointers:
            lines.append(i)
            lines.append('D=M')
            for i in self.__pushDtoStack():                                 
                lines.append(i)
        
        lines.append('@SP')                                                 #Manage ARG // ARG = SP - N - 5
        lines.append('D=M')
        lines.append('@'+str(numArgs))                                      
        lines.append('D=D-A')
        lines.append('@5')
        lines.append('D=D-A')
        lines.append('@ARG')                                                
        lines.append('M=D')
        
        lines.append('@SP')                                                 #Manage LCL // LCL = SP
        lines.append('D=M')
        lines.append('@LCL')                                                
        lines.append('M=D')
        
        lines.append('@' + fnName)                                          #goTo FnName
        lines.append('0;JMP')
        lines.append('('+self.currentFunction+'L'+str(self.labelID)+')')    #Return address
        
        self.currentFunction = fnName+'$'                                   #Reset fucntion name
        self.labelID += 1                                                   #Increment label counter
        
        return lines

    def __generateReturn(self, unused):
        ''' Generates and returns Hack assembler function return code for structured function navigation'''
        lines = []
        lines.append('//__generateReturn')

        lines.append('@LCL')                                                #Set frame to LCL                                           
        lines.append('D=M')
        lines.append('@R15')                                               
        lines.append('M=D')
        lines.append('@5')                                                  
        lines.append('A=D-A')
        lines.append('D=M')
        lines.append('@R14')                                                
        lines.append('M=D') 

        for i in self.__popStacktoD():                                      #ARG pop
            lines.append(i)
            
        lines.append('@ARG')
        lines.append('A=M')
        lines.append('M=D')
        lines.append('D=A+1')

        pointers = ('@SP', '@THAT', '@THIS', '@ARG')                        #Load pointers from the stack
        
        for i in pointers: 
            lines.append(i)
            lines.append('M=D')
            lines.append('@R15')
            lines.append('AM=M-1')
            lines.append('D=M')
         
        lines.append('@LCL')                                                #Manage LCL
        lines.append('M=D')
        lines.append('@R14')                                                #goto Return
        lines.append('A=M')
        lines.append('0;JMP')
        
        return lines
#!/usr/bin/python
#VMtoMnemonics.py
#Loren Peitso (template)
#ver. Ha
#CS2011   Project 7/8 Stack Operations
#Fall 2019
#last updated 08Aug22

import sys                                                                 #for command line launch functionality
import os
from pathlib import * 
from VMParser import *
from VMCodeGenerator import *

FILE = 0
COMPLEX_INIT = 1
    
class VMtoMnemonics(object):
##########################################
#Constructor
    '''Create output file paths'''
    def __init__(self, target):
        
        self.targetPath = Path(target[FILE])
        self.GEN_INIT = target[COMPLEX_INIT]

        if self.targetPath.is_dir():                                                                
            self.outputFilePath = self.targetPath / (self.targetPath.name + '.asm')
#            self.inputFilePath = self.targetPath / (self.targetPath.name + '.vm')
        else:
            if self.targetPath.suffix == '.vm':
                self.outputFilePath = Path(self.targetPath.parent / (self.targetPath.stem + '.asm'))
#                self.inputFilePath = Path(self.targetPath.parent / (self.targetPath.stem + '.vm'))
            else:
                raise RuntimeError('Error, cannot use the filename: ' + target[FILE] )

##########################################
#public methods
    def process(self):
        assemblyCode = []

        #Management for the initial RAM initialization
        self.codeGenerator = VMCodeGenerator( self.targetPath )
        
        if self.GEN_INIT:
            assemblyCode.extend(self.codeGenerator.generateInit())

        for filename in os.listdir(self.targetPath):
            f = os.path.join(self.targetPath, filename)
            
            if '.vm' in f:                                              #Make sure it's a '.vm' file
                self.codeGenerator.fileName = filename.split('.')[0]    #Set fileName in codeGenerator for unique label declaration, and process the file   
                assemblyCode.extend(self.__processFile(f))              #Process the file as appropriate

        return self.__output(assemblyCode)

##########################################
#private methods
    def __processFile(self, filePath):
        '''Processes a single file, returning the translated assembler code.'''       
        assemblyCode = []                                                #Initialize empty array
        self.parser = VMParser(filePath)                                 #Initialize Parser, pass it the input file
        
        ''' Manage the translation to assembler code, returning a list of assembler instructions'''
        line = self.parser.advance()                                     #Get next command
       
        while(line):                                                     #If the command is valid (will kick False if ain't no more commands, Chief)
            instruction = self.codeGenerator.translateLine(line)         #Get a list of instructions from codeGenerator
            for i in instruction:                                        #Loop through instructions... 
                assemblyCode.append(i)                                   #... append them to the assemblerCode list
            line = self.parser.advance()                                 #... and advance to the next line

        for i in self.codeGenerator.end():                               #Pull up and append an infinite loop coda
            assemblyCode.append(i)
        
        return assemblyCode

    def __output(self, codeList):
        '''Outputs the assembler codeList into a file and returns the filename'''           
        file = open(str(self.outputFilePath),"w")
        file.write("\n".join(codeList))
        file.close()
        return str(self.outputFilePath)
        

#################################
#This kicks off the program and assigns the argument to a variable
#
if __name__=="__main__":

    target = eval(sys.argv[1])     # use this one for final deliverable

    translator = VMtoMnemonics(target)
    print('\n' + str( translator.process() ) + ' has been translated.')



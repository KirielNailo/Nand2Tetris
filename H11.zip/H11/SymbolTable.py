# SymbolTable.py
# CS2001   Project 11 
# 31 July 2013
# last updated 05SEP22
# inprog code; ver. Ha

from JTConstants import *

class SymbolTable(object):
############################################
# Constructor
    def __init__(self):
        self.classScope = dict()                            #Dictionary for class scope
        self.subroutineScope = dict()                       #Dictionary for subroutine scope
        
        self.symbols = {ST_STATIC:self.classScope,          #Symbols array
                        ST_FIELD:self.classScope, 
                        ST_ARG:self.subroutineScope, 
                        ST_VAR:self.subroutineScope}

        self.index =   {ST_STATIC:0,                        #Indices array
                        ST_FIELD:0,
                        ST_ARG:0,
                        ST_VAR:0}

############################################
# instance methods
    def startSubroutine(self):
        '''Starts a subroutine scope. '''
        self.subroutineScope.clear()                        #Clear current scope
        self.index[ST_ARG] = self.index[ST_VAR] = 0         #Zeroize Args and Var
 
    def define(self, name, identifierType, kind):
        '''Defines a new identifier into the table. Gets index for appropriate segment and places entry into correct scope
             static and field into class
             arg and var into subroutine
     
            arguments:
             -name:             the identifier itself
             -identifierType:   string identifying the type
             -kind:             'static' | 'field' | 'arg' | 'var' '''

        self.symbols[kind][name] = (identifierType, kind, self.index[kind])
        self.index[kind] += 1

    def typeOf(self, name):
        '''Returns the type of the identifier'''
        (type, kind, index) = self.lookup(name)
        return type

    def kindOf(self, name):
        '''Returns the kind of the identifiers: 'static' | 'field' | 'arg' | 'var' '''
        (type, kind, index) = self.lookup(name)
        return kind

    def indexOf(self, name):
        '''Returns the segment index of the identifier'''
        (type, kind, index) = self.lookup(name)
        return index          

    def howMany(self, kind):
        '''Returns how many variables have been declared for segment kind
                -kind:  'static' | 'field' | 'arg' | 'var' '''       
        return sum(1 for n, (t, k, i) in self.symbols[kind].items() if k == kind)
        
    def lookup(self, name):
        if name in self.subroutineScope:
            return self.subroutineScope[name]
        elif name in self.classScope:
            return self.classScope[name]
        else:
            return (None, None, None)
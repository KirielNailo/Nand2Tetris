# JackAnalyzer.py
# CS2001   Project 11 
# 31 July 2013
# last updated 05SEP22
# inprog code; ver. Ha

import sys                                                                                          #for command line launch functionality
from pathlib import *                                                                               #for sane and modern file access

from JackTokenizer import *
from CompilationEngine import *
from JTConstants import *

############################################
# Class
class JackAnalyzer(object):

##########################################
#Constructor

    def __init__(self, target):
        self.targetPath = Path(target)

##########################################
#instance methods

    def process(self):
        
        if self.targetPath.is_dir():
            
            #manage cross OS differences in directory iterations
            paths_for_rearranging = [
                Path(path)
                for path in self.targetPath.iterdir()
            ]
            sorted_paths = sorted(paths_for_rearranging)
            
            for eachFile in sorted_paths:
                if eachFile.suffix == '.jack':
                    self.__processFile(eachFile)
        else:
            if (self.targetPath.suffix != '.jack'):
                raise RuntimeError("Error, cannot use the filename: " + self.targetPath.name )

            self.__processFile(self.targetPath)
        
        return str(self.targetPath)

##########################################
#private methods
    def __processFile(self, filePath):
        
        print('Processing', filePath)
              
        #Tokenize supplied file
        tokenOutputFilePath = filePath.parent / (filePath.stem + 'T.xml')
        tokenList = []        
        tokenList = self.__tokenize(filePath)
        self.__output(tokenOutputFilePath, tokenList)                                                   #Print token list into an intermediate file

        #Compile provided list of tokens
        intermediateOutputFilePath = filePath.parent / (filePath.stem + '.xml')
        compiledXML = []  
        ce = CompilationEngine(tokenList)
        compiledXML = ce.compileTokens()
        self.__output(intermediateOutputFilePath, compiledXML)                                          #Print XML-formatted program
        
        #Compile provided list of tokens into vm commands
        finalOutputFilePath = filePath.parent / (filePath.stem + '.vm')
        compiledVM = []  
        compiledVM = ce.get_vmInstructions()
        self.__output(finalOutputFilePath, compiledVM)                                                  #Print a set of VM instructions

    def __tokenize(self, filePath):
        ''' tokenizes the file, returns a list of one XML-formatted token per line'''
        tokenList = []

        jt = JackTokenizer(filePath)
        tokenList.append('<tokens>')

        token = jt.advance()                                                                            #Get next command
       
        while(token):                                                                                   #If the command is valid           
            tokenList.append(self.__wrapTokenInXML(token))                                              #Send the token to be identified; then appropriately sandwich between xml type tags          
            token = jt.advance()                                                                        #... and advance to the next line

        tokenList.append('</tokens>') 
        
        return tokenList

    def __wrapTokenInXML(self, token):
        ''' returns a string where the token is properly sandwiched between type tags'''
        tokenString = ''
        
        if token in KEYWORDS:                   
            tokenString = '<keyword> '+token+' </keyword>'                                              #Assign token keyword
        elif token in SYMBOLS:
            if token in '<>&':
                token = glyphSubstitutes[token]
            tokenString = '<symbol> '+token+' </symbol>'                                                #Assign token symbol
        else:
            if token.isnumeric():
                tokenString = '<integerConstant> '+token+' </integerConstant>'                          #Assign token as an integerConstant
            elif '<stringConstant>' in token:                                                           #Recognize token as a stringConstant - assignment happens elsewhere
                tokenString = token
            else: 
                tokenString = '<identifier> '+token+' </identifier>'                                    #Default case, assign token as an identifier
                      
        return tokenString

    def __output(self, filePath, codeList):
        ''' outputs the VM code codeList into a file and returns the file path'''
            
        file = open(str(filePath), 'w')
        file.write("\n".join(codeList))
        file.close()
        return filePath

#################################
#################################
#################################
#this kicks off the program and assigns the argument to a variable
#
if __name__=="__main__":

    target = sys.argv[1]         # use this one for final deliverable
    
    analyzer = JackAnalyzer(target)
    print('\n' + analyzer.process() + ' has  been translated.')







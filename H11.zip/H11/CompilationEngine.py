# CompilationEngine.py
# CS2001   Project 11 
# 31 July 2013
# last updated 05SEP22
# inprog code; ver. Ha

from JTConstants import *
from SymbolTable import *

# Used for the peek/get/replace functions
TT_TOKEN = 0
TT_XML = 1

#map from Jack language purpose term in SymbolTable, to VM segment name
SEG = {'static':'static', 'field':'this', 'arg':'argument', 'var':'local'}
   
############################################
# Class
class CompilationEngine(object):

############################################
#static class variables
#   these will be shared across multiple instances

    labelID = 0

############################################
# Constructor
    def __init__(self, tokenList):
        self.tokens = tokenList
        self.indentation = 0
        self.st = SymbolTable()
        self.vmInstList = []
        self.currentClassName = None
        self.currentToken = None
        
############################################
# static class methods
    @staticmethod
    def __getLabelNumber():
        ''' a static utility method to access the class variable '''
        label = CompilationEngine.labelID                                                       #Maintain unique label counter across the set of CompilationEngine instances
        CompilationEngine.labelID += 1
        return ( str(label) )

############################################
# instance methods
    def compileTokens(self):
        ''' primary call to do the final compilation.
            returns a list of properly identified structured XML with appropriate indentation.'''       
        result = []

        tokenTuple = self.__getNextEntry()

        if ( tokenTuple[TT_XML] == '<tokens>' ):
            result.extend( self.__compileClass() )

            tokenTuple = self.__getNextEntry()
            if ( tokenTuple[TT_XML] != '</tokens>' ):
                raise RuntimeError('Error, this file was not properly tokenized, missing </tokens>')
                
        else:
            raise RuntimeError('Error, this file was not properly tokenized, missing <tokens>')

        return result

    def get_vmInstructions(self):
        ''' returns a fully translated list of vm instructions, one instruction per list element '''
        return self.vmInstList

############################################
# private/utility methods
    def __getNextEntry(self):
        '''Removes the next token from the list of tokens returns a tuple (token, <tag> token </tag>)'''
        tokenString = self.tokens.pop(0)
        startIndex = tokenString.find('>') + 2 
        endIndex = tokenString.find('</') - 1
        tokenTuple = (tokenString[startIndex:endIndex], tokenString)
        return tokenTuple

    def __peekAtNextEntry(self):
        '''Copies, but does not remove the next token from the datastream returns a tuple (token, <tag> token </tag>)'''
        tokenString = self.tokens[0]
        startIndex = tokenString.find('>') + 2
        endIndex = tokenString.find('</') - 1
        tokenTuple = (tokenString[startIndex:endIndex] , tokenString)
        return tokenTuple                                                           

    def __compileClass(self):
        '''Compiles a class declaration, returning a list of VM commands. '''       
        result = []
        tokenTuple = self.__getNextEntry()
        if tokenTuple[TT_TOKEN] == 'class':
            
            result.append( '<class>' )                                                          #<class>
            self.indentation += 2  
            result.append( (self.indentation * ' ') + tokenTuple[TT_XML])                       #Keyword class
            result.extend(self.__append())                                                      #Classname identifier
            self.currentClassName = self.currentToken                                           #Save current class name on the instance
            result.extend(self.__append())                                                      #Symbol '{'

            tokenTuple = self.__peekAtNextEntry()            
            while tokenTuple[TT_TOKEN] != '}':                                                  #While peek not '}'
                if (tokenTuple[TT_TOKEN] == 'field') or (tokenTuple[TT_TOKEN] == 'static'):     #if field | static
                    result.extend( self.__compileClassVarDec() )                                #__compileClassVarDec 
                elif( tokenTuple[TT_TOKEN] in SUBROUTINES ):                                    #if in SUBROUTINES
                    result.extend( self.__compileSubroutine())                                  #__compileSubroutine   
                else:
                    raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not subroutineDec or classVarDec')
                tokenTuple = self.__peekAtNextEntry()

            result.extend(self.__append())                                                      #Symbol '}'
            self.indentation -= 2
            result.append( '</class>' )                                                         #</class>           
        else:
            raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not class')
        
        return result

    def __compileClassVarDec(self):
        '''Compiles a class variable declaration statement, returning a list of VM commands. '''
        result = []        
        kind = ''
        type = ''
        result.append( (self.indentation * ' ') + '<classVarDec>' )                             #<classVarDec>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword static or field
        
        if(self.currentToken == 'static'):                                                      #Set variable kind (static | field)
            kind = ST_STATIC
        else: 
            kind = ST_FIELD
        
        result.extend(self.__append())                                                          #Keyword var type      
        type = self.currentToken                                                                #Set variable type

        result.extend(self.__append())                                                          #Identifier VarName
        self.st.define(self.currentToken, type, kind)                                           #Save variable to ST
        
        tokenTuple = self.__peekAtNextEntry()            
        while tokenTuple[TT_TOKEN] != ';':                                                      #While peek not ';'
            result.extend(self.__append())                                                      #Symbol ','
            result.extend(self.__append())                                                      #Identifier varName
            self.st.define(self.currentToken, type, kind)                                       #Save variable to ST
            tokenTuple = self.__peekAtNextEntry()

        result.extend(self.__append())                                                          #Symbol ';'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</classVarDec>' )                            #</classVarDec>
        
        return result
   
    def __compileSubroutine(self):
        '''Compiles a function/method, returning a list of VM commands. '''        
        result = []
        result.append( (self.indentation * ' ') + '<subroutineDec>' )                           #<subroutineDec>
        self.indentation += 2      
        
        result.extend(self.__append())                                                          #Keyword constructor/function/method
        subroutineType = self.currentToken
        result.extend(self.__append())                                                          #Keyword void/type
        returnType = self.currentToken                                                          #Set subroutine type
        result.extend(self.__append())                                                          #Subroutine name
        subroutineName = self.currentToken                                                      #Set subroutine name
        
        self.st.define(subroutineName, subroutineType, ST_STATIC)                               #Save variable to ST
        self.st.startSubroutine()                                                               #Start Subroutine scope in Symbol Table
        
        result.extend(self.__append())                                                          #Symbol '(' 
        result.extend(self.__compileParameterList(subroutineName))                              #__parameterList       
        result.extend(self.__append())                                                          #Symbol ')'
        result.extend(self.__compileSubroutineBody(subroutineName))                             #__compileSubroutineBody      
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</subroutineDec>' )                          #</subroutineDec>
        
        return result
    
    def __compileParameterList(self, subroutineName):
        '''Compiles a parameter list from a function/method returning a list of VM commands. '''
        result = []       
            
        result.append( (self.indentation * ' ') + '<parameterList>')                            #parameterList
        self.indentation += 2       

        if self.st.typeOf(subroutineName) == 'method':                                          #If method, save a dummy arg to shift AGR counter 0 -> 1
            self.st.define('BLANK', 'BLANK', ST_ARG)

        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] != ')'):                                                       #Closing ')' from subroutineDec; ( printed by subroutineDec
            result.extend(self.__append())                                                      #type    
            type = self.currentToken                                                            #Set variable type
            result.extend(self.__append())                                                      #varName
            self.st.define(self.currentToken, type, ST_ARG)                                     #Save variable to ST

        tokenTuple = self.__peekAtNextEntry() 
        while tokenTuple[TT_TOKEN] == ',':                                                      #Preceding comma for the parameter in parameter list
            result.extend(self.__append())                                                      #Symbol ','
            result.extend(self.__append())                                                      #type    
            type = self.currentToken                                                            #Set variable type
            result.extend(self.__append())                                                      #varName    
            self.st.define(self.currentToken, type, ST_ARG)                                     #Save variable to ST
            tokenTuple = self.__peekAtNextEntry()          
        
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</parameterList>')                           #/parameterList, ')'
        
        return result
        
    def __compileSubroutineBody(self, subroutineName):
        '''Compiles a parameter list from a function/method returning a list of VM commands. '''
        result = []
        wroteSubroutine = False
        result.append( (self.indentation * ' ') + '<subroutineBody>')                           #<subroutineBody>
        self.indentation += 2                
        result.extend(self.__append())                                                          #Symbol '{'
        
        tokenTuple = self.__peekAtNextEntry()
        while tokenTuple[TT_TOKEN] != '}':                                                      #Check for closing '}'                  
            if (tokenTuple[TT_TOKEN] == 'var'):                                                 #if a varDec
                result.extend( self.__compileVarDec() )                                         #__compileVarDec
            elif tokenTuple[TT_TOKEN] in STATEMENTS:                                            #if a statement
                if not wroteSubroutine:                 
                    #VM code for calling the subroutine... putting here to account for the numVar option                   
                    self.vmInstList.append('function ' + self.currentClassName + '.' + subroutineName + ' ' + str(self.st.howMany(ST_VAR)))
                    if self.st.typeOf(subroutineName) == 'method':                              #Account for method
                        self.vmInstList.append('push argument 0')
                        self.vmInstList.append('pop pointer 0')
                    if self.st.typeOf(subroutineName) == 'constructor':                         #Account for constructor
                        self.vmInstList.append('push constant ' + str(self.st.howMany(ST_FIELD)))                       
                        self.vmInstList.append('call Memory.alloc 1')
                        self.vmInstList.append('pop pointer 0')                                 #Set 'this' in the function to allow it to return it                                
                    wroteSubroutine = True
                result.extend( self.__compileStatements())                                      #__compileStatements
            else: 
                raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not a variable declaration or a statement.')                
            tokenTuple = self.__peekAtNextEntry()
        
        result.extend(self.__append())                                                          #Symbol '}'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</subroutineBody>')                          #</subroutineBody>
        return result
  
    def __compileVarDec(self):
        '''Compiles a single variable declaration line, returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<varDec>')                                   #<varDec>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword var  
        result.extend(self.__append())                                                          #Identifier type 
        type = self.currentToken                                                                #Set variable type
        result.extend(self.__append())                                                          #Identifier varName
        self.st.define(self.currentToken, type, ST_VAR)                                         #Save variable to ST
        #Dummy code for applying correct xml tags to identify saved variable to xml. Deemed not necessry for my purposes -> I did not follow through to... 
        #...add the same code to other instances of variable declaration / useage. I can chuck this code into other decl/use places, I just don't see a point.
        #VM works.
        symbolDefined = 'subroutine.' + self.currentToken + ' (var ' + type + ') = ' + str(self.st.indexOf(self.currentToken))
        symbolDefined = '<SYMBOL-Defined> ' + symbolDefined + ' </SYMBOL-Defined>'
        result.append( (self.indentation * ' ') + symbolDefined)
        
        tokenTuple = self.__peekAtNextEntry()                
        while tokenTuple[TT_TOKEN] != ';':                                                      #While peek not ';'
            result.extend(self.__append())                                                      #Symbol ','           
            result.extend(self.__append())                                                      #Identifier varName
            self.st.define(self.currentToken, type, ST_VAR)                                     #Save variable to ST
            #Same as above. If need to, will probably make it a subroutine. 
            symbolDefined = 'subroutine.' + self.currentToken + ' (var ' + type + ') = ' + str(self.st.indexOf(self.currentToken))
            symbolDefined = '<SYMBOL-Defined> ' + symbolDefined + ' </SYMBOL-Defined>'
            result.append( (self.indentation * ' ') + symbolDefined)
            tokenTuple = self.__peekAtNextEntry()
              
        result.extend(self.__append())                                                          #Symbol ';' 
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</varDec>' )                                 #</varDec>
        
        return result

    def __compileStatements(self):
        '''Compiles statements, returning a list of VM commands, assumes any leading and trailing braces are consumed by the caller '''
        result = []       
        result.append( (self.indentation * ' ') + '<statements>')                               #<statements>
        self.indentation += 2

        tokenTuple = self.__peekAtNextEntry()       
        while  tokenTuple[TT_TOKEN] != '}':                                                     #While not '}'
            if (tokenTuple[TT_TOKEN] == 'let'):                                                 #if letStatement
                result.extend( self.__compileLet() )                                
            elif (tokenTuple[TT_TOKEN] == 'if'):                                                #if ifStatement
                result.extend( self.__compileIf())           
            elif (tokenTuple[TT_TOKEN] == 'while'):                                             #if whileStatement
                result.extend( self.__compileWhile())
            elif (tokenTuple[TT_TOKEN] == 'do'):                                                #if doStatement
                result.extend( self.__compileDo())          
            elif (tokenTuple[TT_TOKEN] == 'return'):                                            #if returnStatement
                result.extend( self.__compileReturn())            
            else:
                raise RuntimeError('Error, token provided:', tokenTuple[TT_TOKEN], ', is not a valid Statement')                          
            tokenTuple = self.__peekAtNextEntry()
              
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</statements>' )                             #</statements>
        return result

    def __compileLet(self):
        '''Compiles a variable assignment statement, returning a list of VM commands. '''
        result = []      
        result.append( (self.indentation * ' ') + '<letStatement>')                             #<letStatement>
        self.indentation += 2       
        result.extend(self.__append())                                                          #Keyword let        
        result.extend(self.__append())                                                          #Identifier varName
        varName = self.currentToken

        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] == '['):                                                       #Check for array indicator [      
            result.extend(self.__append())                                                      #Symbol '['
            result.extend( self.__compileExpression())                                          #__compileExpression
            result.extend(self.__append())                                                      #Symbol ']'
            result.extend(self.__append())                                                      #Symbol '='        
            result.extend( self.__compileExpression())                                          #__compileExpression 
            self.vmInstList.append('pop temp 0')                                                #Let pushes/pops to account for array logic
            self.vmInstList.append(self.__pushVariable(varName))     
            self.vmInstList.append('add')                                                       
            self.vmInstList.append('pop pointer 1')
            self.vmInstList.append('push temp 0')
            self.vmInstList.append('pop that 0')
        else:    
            result.extend(self.__append())                                                      #Symbol '='        
            result.extend( self.__compileExpression())                                          #__compileExpression 
            self.vmInstList.append(self.__popVariable(varName))                                 #Pop final variable
        
        result.extend(self.__append())                                                          #Symbol ';'        
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</letStatement>' )                           #</letStatement>
        
        return result   

    def __compileIf(self):
        ''' compiles an if(else)? statement ''' 
        result = []  
        ifLabel = str(self.__getLabelNumber())                                                  #Reserve label index
        result.append( (self.indentation * ' ') + '<ifStatement>')                              #<ifStatement>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword if       
        result.extend(self.__append())                                                          #Symbol '('
        result.extend( self.__compileExpression())                                              #__compileExpression       
        result.extend(self.__append())                                                          #Symbol ')'  
        result.extend(self.__append())                                                          #Symbol '{'
        
        self.vmInstList.append('not')
        self.vmInstList.append('if-goto DO_ELSE_' + ifLabel)                                    #First label
        result.extend( self.__compileStatements())                                              #__compileStatements
        self.vmInstList.append('goto IF_THEN_COMPLETE_' + ifLabel)                              #Second label
        self.vmInstList.append('label DO_ELSE_' + ifLabel)                                      #Third label
        result.extend(self.__append())                                                          #Symbol '}'
        
        tokenTuple = self.__peekAtNextEntry()                 
        if (tokenTuple[TT_TOKEN] == 'else'):                                                    #verify if 'if' has 'else'            
            result.extend(self.__append())                                                      #Keyword else            
            result.extend(self.__append())                                                      #Symbol '{'           
            result.extend( self.__compileStatements())                                          #__compileStatements           
            result.extend(self.__append())                                                      #Symbol '}'
        
        self.vmInstList.append('label IF_THEN_COMPLETE_' + ifLabel)                             #Final label
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</ifStatement>' )                            #</ifStatement>
        
        return result
    
    def __compileWhile(self):
        '''Compiles a while loop, returning a list of VM commands. '''
        result = []      
        whileLabel = str(self.__getLabelNumber())                                               #Reserve label index        
        result.append( (self.indentation * ' ') + '<whileStatement>')                           #<whileStatement>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword while
        result.extend(self.__append())                                                          #Symbol '('
        self.vmInstList.append('label WHILE_TOP_' + whileLabel)                                 #First label
        result.extend( self.__compileExpression())                                              #__compileExpression
        self.vmInstList.append('not') 
        self.vmInstList.append('if-goto WHILE_EXIT_' + whileLabel)                              #Second label
        result.extend(self.__append())                                                          #Symbol ')'
        result.extend(self.__append())                                                          #Symbol '{'
        result.extend( self.__compileStatements())                                              #__compileStatements
        self.vmInstList.append('goto WHILE_TOP_' + whileLabel)                                  #Third label
        self.vmInstList.append('label WHILE_EXIT_' + whileLabel)                                #Final label
        result.extend(self.__append())                                                          #Symbol '}'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</whileStatement>' )                         #</whileStatement>
        return result

    def __compileDo(self):
        '''Compiles a function/method call, returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<doStatement>')                              #<doStatement>
        self.indentation += 2 
        result.extend(self.__append())                                                          #Keyword do
        #I was an idiot. Instead of doing two distinct subroutine calls done differently from two different places... 
        #...I could have just realized that I can call 'term' here instead, and push '__compileSubroutineCall into __compileTerm...
        #...solving the dichtonomy. Which is what I've done. That took entirely too long and was a source of much anguish.
        result.extend( self.__compileTerm())                                                    #__compileTerm // subroutine call is a subset of term
        self.vmInstList.append('pop temp 0')                                                    #Cleanup
        result.extend(self.__append())                                                          #Symbol ';'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</doStatement>' )                            #</doStatement>
        
        return result

    def __compileReturn(self):
        '''Compiles a function return statement, returning a list of VM commands. '''
        result = []
        result.append( (self.indentation * ' ') + '<returnStatement>')                          #<returnStatement>
        self.indentation += 2
        result.extend(self.__append())                                                          #Keyword return
        
        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] != ';'):                                                       #if not ';'
            result.extend( self.__compileExpression())                                          #__compileExpression
        else:
            self.vmInstList.append('push constant 0')                                           #If no expression, we assume it's a void and push 0 
                                                                                                #Pretty hacky way to do it, but it works! 
        
        self.vmInstList.append('return')                                                        #VM command return
        result.extend(self.__append())                                                          #Symbol ';'
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</returnStatement>' )                        #</returnStatement>
        
        return result

    #Tentatively complete
    def __compileExpression(self):
        '''Compiles an expression, returning a list of VM commands.'''
        result = []      
        result.append( (self.indentation * ' ') + '<expression>')                               #<expression>
        self.indentation += 2
        
        result.extend( self.__compileTerm())                                                    #__compileTerm
                                                                       
        tokenTuple = self.__peekAtNextEntry()       
        while tokenTuple[TT_TOKEN] in BINARY_OPERATORS:                                         #Check if next token is an operator          
            result.extend(self.__append())                                                      #Operator            
            operator = self.currentToken
            result.extend( self.__compileTerm())                                                #__compileTerm
            self.vmInstList.append(str(BINARY_OPERATORS[operator]))                             #VM code for an operator
            tokenTuple = self.__peekAtNextEntry()
            
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</expression>' )                             #</expression>
        return result

    def __compileTerm(self):
        '''Compiles a term, returning a list of VM commands.'''
        #... no polite words left. The core of everything, quite frankly. 
        result = []
        result.append( (self.indentation * ' ') + '<term>')                                     #<term>
        self.indentation += 2
        
        tokenTuple = self.__peekAtNextEntry()
        if (tokenTuple[TT_TOKEN] == '('):                                                       #expression case, look for '(' indicator          
            result.extend(self.__append())                                                      #Symbol '('
            result.extend( self.__compileExpression())                                          #__compileExpression           
            result.extend(self.__append())                                                      #Symbol ')'
        elif tokenTuple[TT_TOKEN] in SYMBOLS:                                                   #"unaryOP term" case
            result.extend(self.__append())                                                      #operator
            if(self.currentToken == '-'): 
                result.extend(self.__compileTerm())
                self.vmInstList.append('neg')                                                   #VM code for -
            elif(self.currentToken == '~'):
                result.extend(self.__compileTerm())
                self.vmInstList.append('not')                                                   #VM code for ~
            else:
                result.extend(self.__compileTerm())                                             #__compileTerm
        else:                                                                                   #...in every other case
            result.extend(self.__append())                                                      #integerConstant | stringConstant | keywordConstant | varName | first element of subroutineCall            
            
            if 'stringConstant' in tokenTuple[TT_XML]:                                          #VM code for stringConstant
                self.vmInstList.append('push constant ' + str(len(self.currentToken)))          #Push stringLenght
                self.vmInstList.append('call String.new 1')                                     #Call new string
                for c in self.currentToken:                                                     #Append charater one-by-one
                    self.vmInstList.append('push constant ' + str(ord(c)))
                    self.vmInstList.append('call String.appendChar 2')
            elif 'integerConstant' in tokenTuple[TT_XML]:                                       #VM code for integerConstant
                self.vmInstList.append('push constant ' + str(self.currentToken))
            elif 'keyword' in tokenTuple[TT_XML]:                                               #VM code for keyword
                if self.currentToken == 'this':                                                 #Account for 'this' case
                    self.vmInstList.append('push pointer 0') 
                else:
                    self.vmInstList.append('push constant 0')                                   #Account for all other cases
                    if self.currentToken == 'true':                                 
                        self.vmInstList.append('not')                                                                     
            elif 'identifier' in tokenTuple[TT_XML]:                                            #Case for varName
                varName = self.currentToken
                tokenTuple = self.__peekAtNextEntry()           
                if (tokenTuple[TT_TOKEN] == '['):                                               #Case for an array in varName   
                    result.extend(self.__append())                                              #Symbol '['
                    result.extend(self.__compileExpression())                                   #__compileExpression
                    self.vmInstList.append(self.__pushVariable(varName))                        #Adjust code to adjust 'that' to var + index
                    self.vmInstList.append('add')
                    self.vmInstList.append('pop pointer 1')
                    self.vmInstList.append('push that 0')                                       
                    result.extend(self.__append())                                              #Symbol ']'
                else:                                                                           #Either subroutine call case, or a var case
                    subroutineName = varName                                                    #Save subroutine in case it's not a . call
                    functionClass = self.currentClassName                                       #Identify the class this subroutine belongs to
                    dCall = True                                                                #Set Default Call flag
                    numArgs = 0                                                                 #Set number of arguments
                    
                    tokenTuple = self.__peekAtNextEntry()                                       #expression case '('               
                    if tokenTuple[TT_TOKEN] == '.':                                             #className | varName case
                        dCall = False                                                           #Not a Default Call
                        result.extend(self.__append())                                          #Symbol '.'        
                        result.extend(self.__append())                                          #Subroutine name 2           
                        subroutineName = self.currentToken                                      #Reset subroutine name

                        if self.st.typeOf(varName):                                             #If the object exists
                            functionClass = self.st.typeOf(varName)                             #Set Class to the Class of the Object 
                            numArgs = 1                                                         #Initial Args to 1
                            self.vmInstList.append(self.__pushVariable(varName))                #Push varName
                        else:
                           functionClass = varName                                              #Otherwise Class is the subroutine
                
                    tokenTuple = self.__peekAtNextEntry()                          
                    if (tokenTuple[TT_TOKEN] == '('):  
                        if dCall:                                                               #If not a . call
                            numArgs = 1                                                         #Set numArgs
                            self.vmInstList.append('push pointer 0')                            #Push pointer
                    
                        result.extend(self.__append())                                          #Symbol '('
                        expList = self.__compileExpressionList()
                        result.extend(expList[0])                                               #__compileExpressionList
                        numArgs = numArgs + expList[1]
                        result.extend(self.__append())                                          #Symbol ')'
                        #Write correct subroutine call
                        self.vmInstList.append('call ' + str(functionClass) + '.' + subroutineName + ' ' + str(numArgs))
                    else: 
                        tokenTuple = self.__peekAtNextEntry()
                        self.vmInstList.append(self.__pushVariable(varName))                    #Take care of variables case
                
        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</term>' )                                   #</term>
        
        return result

    def __compileExpressionList(self):
        ''' compiles a list of expressions such as found in a list of arguments for a function call (one expression per argument) 
            returning a tuple whose 0th item is a list of VM commands and the 1th item is the number of parameters in the subroutine. ''' 
        result = []
        num_params = 0
        result.append( (self.indentation * ' ') + '<expressionList>')                           #<expressionList>
        self.indentation += 2
 
        tokenTuple = self.__peekAtNextEntry()
        if tokenTuple[TT_TOKEN] != ')':                                                         #Check for symbol ')' -> closing for subroutineCall
            result.extend( self.__compileExpression())                                          #__compileExpression
            num_params += 1
            
            tokenTuple = self.__peekAtNextEntry()                                       
            while tokenTuple[TT_TOKEN] == ',':                                                  #check for continued expressions           
                result.extend(self.__append())                                                  #Symbol ','
                result.extend( self.__compileExpression())                                      #__compileExpression
                num_params += 1
                tokenTuple = self.__peekAtNextEntry()

        self.indentation -= 2
        result.append( (self.indentation * ' ') + '</expressionList>' )                         #</expressionList>
        
        return (result, num_params)

    def __pushVariable(self, name): 
        '''Helper function. Generates push string off the variable name'''
        if self.st.kindOf(name) == 0:
            mappedVar = 'static'
        elif self.st.kindOf(name) == 1:
            mappedVar = 'this'
        elif self.st.kindOf(name) == 2:B
            mappedVar = 'argument'
        elif self.st.kindOf(name) == 3:
            mappedVar = 'local'
        else: 
            mappedVar = 'ERROR'
    
        return 'push ' + mappedVar + ' ' + str(self.st.indexOf(name))
        
    def __popVariable(self, name):         
        '''Helper function. Generates pop string off the variable name'''
        if self.st.kindOf(name) == 0:
            mappedVar = 'static'
        elif self.st.kindOf(name) == 1:
            mappedVar = 'this'
        elif self.st.kindOf(name) == 2:
            mappedVar = 'argument'
        elif self.st.kindOf(name) == 3:
            mappedVar = 'local'
        else: 
            mappedVar = 'ERROR'
    
        return 'pop ' + mappedVar + ' ' + str(self.st.indexOf(name))
        
    def __append(self):
        '''Gets next token, appends next token to the results. Keeps me honest with the order of operations.'''
        result = []       
        tokenTuple = self.__getNextEntry()
        result.append( (self.indentation * ' ') + tokenTuple[TT_XML])
        self.currentToken = tokenTuple[TT_TOKEN]
        #print((self.indentation * ' ') + tokenTuple[TT_XML])
        
        return result
